# Flashcard
**I HAVE NO CLUE IF ITS NETWORKED, ITS 12:30 AM, I WANNA GO TO SLEEP LMAO**
For now make sure everyone has the same config.

Current Features:
- Allows you to change the max length of videos you can film with the camera.
 - By default Flashcard increases it from 90 (vanilla default) to 120 (2 minutes, flashcard default)
- nothing else lol (there will be more later)