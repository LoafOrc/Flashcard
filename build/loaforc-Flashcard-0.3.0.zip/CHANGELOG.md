# v0.3.0
- Added config option to change the games max packet size when uploading a clip to friends
- Added some "max limits" to config options. You can go past these but I really don't recommend it. 
- Fixed a command injection exploit (big oops)
- Fixed an issue where setting the clip length to the vanilla default of 90 would cause the camera to reset its film amount when being picked up.